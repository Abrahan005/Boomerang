// -------------------------
// Lista de productos (puedes reemplazar por un fetch a get_products.php)
// -------------------------
const productos = [
  {
    id: 1,
    nombre: "Laptop Gamer Lenovo",
    categoria: "Tecnología",
    precio: 3200,
    imagen: "img/lenovo loq.avif"
  },
  {
    id: 1,
    nombre: "Laptop Gamer Lenovo",
    categoria: "Tecnología",
    precio: 3200,
    imagen: "img/lenovo loq.avif"
  },
  {
    id: 1,
    nombre: "Laptop Gamer Lenovo",
    categoria: "Tecnología",
    precio: 3200,
    imagen: "img/lenovo loq.avif"
  },
  {
    id: 1,
    nombre: "Laptop Gamer Lenovo",
    categoria: "Tecnología",
    precio: 3200,
    imagen: "img/lenovo loq.avif"
  },
  {
    id: 2,
    nombre: "Camiseta Oversize",
    categoria: "Ropa",
    precio: 55,
    imagen: "img/camiseta.jpg"
  },
  {
    id: 3,
    nombre: "Robot Interactivo",
    categoria: "Juguetes",
    precio: 120,
    imagen: "img/robot.jpg"
  },
  {
    id: 4,
    nombre: "Set de Maquillaje",
    categoria: "Belleza",
    precio: 85,
    imagen: "img/maquillaje.jpg"
  }
];

// -------------------------
// Elementos DOM
// -------------------------
const contenedor = document.getElementById("productos");
const busquedaInput = document.getElementById("busqueda");
const botonesCategorias = document.querySelectorAll(".categoria-btn");

// -------------------------
// Estado
// -------------------------
let categoriaActual = "Todos";
let carrito = JSON.parse(localStorage.getItem('carrito')) || [];

// -------------------------
// Mostrar productos en cards
// -------------------------
function mostrarProductos(lista) {
  contenedor.innerHTML = "";
  if (lista.length === 0) {
    contenedor.innerHTML = "<p>No se encontraron productos.</p>";
    return;
  }

  lista.forEach(prod => {
    const card = document.createElement("div");
    card.classList.add("product-card");

    card.innerHTML = `
      <img src="${prod.imagen}" alt="${prod.nombre}">
      <div class="info">
        <h3>${prod.nombre}</h3>
        <p class="precio">S/. ${prod.precio}</p>
        <button class="agregar-carrito">Agregar al carrito</button>
      </div>
    `;

    // Evento para agregar al carrito
    card.querySelector(".agregar-carrito").addEventListener("click", (e) => {
      e.stopPropagation();
      agregarAlCarrito(prod);
    });

    // Evento para ir al detalle del producto
    card.addEventListener("click", () => {
      window.location.href = `producto.html?id=${prod.id}`;
    });

    contenedor.appendChild(card);
  });
}

// -------------------------
// Filtrar productos
// -------------------------
function filtrarProductos() {
  const texto = busquedaInput.value.toLowerCase();
  let filtrados = productos.filter(prod => {
    const coincideTexto = prod.nombre.toLowerCase().includes(texto);
    const coincideCategoria = categoriaActual === "Todos" || prod.categoria === categoriaActual;
    return coincideTexto && coincideCategoria;
  });
  mostrarProductos(filtrados);
}

// -------------------------
// Eventos: búsqueda y categorías
// -------------------------
botonesCategorias.forEach(boton => {
  boton.addEventListener("click", () => {
    categoriaActual = boton.dataset.categoria;
    filtrarProductos();
  });
});

busquedaInput.addEventListener("input", filtrarProductos);

// -------------------------
// Función: agregar al carrito
// -------------------------
function agregarAlCarrito(producto) {
  let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
  carrito.push(producto);
  localStorage.setItem("carrito", JSON.stringify(carrito));
  alert("Producto agregado al carrito");
}


// -------------------------
// Mostrar carrito en carrito.html
// -------------------------
document.addEventListener("DOMContentLoaded", function () {
  mostrarCarrito();
});

function mostrarCarrito() {
  const carrito = JSON.parse(localStorage.getItem("carrito")) || [];
  const carritoItems = document.getElementById("carrito-items");
  const totalSpan = document.getElementById("total");

  carritoItems.innerHTML = "";

  let total = 0;

  carrito.forEach(producto => {
    const div = document.createElement("div");
    div.classList.add("carrito-item");
    div.textContent = `${producto.nombre} - S/ ${producto.precio.toFixed(2)}`;
    carritoItems.appendChild(div);
    total += producto.precio;
  });

  totalSpan.textContent = `S/ ${total.toFixed(2)}`;
}


// -------------------------
// Eliminar producto del carrito
// -------------------------
function eliminarDelCarrito(indice) {
  carrito.splice(indice, 1);
  localStorage.setItem('carrito', JSON.stringify(carrito));
  mostrarCarrito();
}

// -------------------------
// Finalizar compra
// -------------------------
function finalizarCompra() {
  if (carrito.length === 0) {
    alert('Tu carrito está vacío');
    return;
  }

  alert('¡Gracias por tu compra!');
  carrito = [];
  localStorage.removeItem('carrito');
  mostrarCarrito();
}

// -------------------------
// Inicializar
// -------------------------
document.addEventListener('DOMContentLoaded', () => {
  if (window.location.pathname.includes('carrito.html')) {
    mostrarCarrito();
  } else {
    mostrarProductos(productos);
  }
});
